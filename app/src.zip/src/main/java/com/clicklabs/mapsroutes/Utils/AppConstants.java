package com.clicklabs.mapsroutes.Utils;

/**
 * Created by hp- on 29-02-2016.
 */
public class AppConstants {
    public static final String Google_places_Server_Key="AIzaSyC-7h6OOvcZE6GCl3jzfWpMdGa1JLr46WQ";
}
